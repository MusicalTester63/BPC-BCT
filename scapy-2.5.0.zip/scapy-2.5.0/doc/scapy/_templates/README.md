# Doc templates

This folder contains templates used to generate Scapy's doc. It contains:

- apidoc templates: inherited from
  https://github.com/sphinx-doc/sphinx/blob/master/sphinx/templates/apidoc/
